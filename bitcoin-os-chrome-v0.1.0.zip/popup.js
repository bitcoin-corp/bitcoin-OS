document.addEventListener('DOMContentLoaded', function() {
  const openAppBtn = document.getElementById('openApp');
  const appButtons = document.querySelectorAll('.app-btn');
  
  // Open main Bitcoin OS app
  openAppBtn.addEventListener('click', function() {
    chrome.tabs.create({
      url: 'https://bitcoin-os.vercel.app'
    });
    window.close();
  });
  
  // Handle app button clicks
  appButtons.forEach(button => {
    button.addEventListener('click', function() {
      const app = this.getAttribute('data-app');
      chrome.tabs.create({
        url: `https://bitcoin-os.vercel.app/#${app}`
      });
      window.close();
    });
  });
});